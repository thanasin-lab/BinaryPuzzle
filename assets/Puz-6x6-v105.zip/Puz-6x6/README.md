# Binary Puzzle - Teacher site

This version is 6x6, but enterprising students may want to code for a variable size.
A puzzle converting a 1D array to 2D. It's fun too!

The index file links to the versions as evolve.
